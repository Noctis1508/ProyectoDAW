<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
?>

<link rel="stylesheet" href="<?= BASE_URL ?>assets/css/styles.css">

<nav class="navbar navbar-expand-lg navbar-dark bg-dark px-4">
<a href="<?= BASE_URL ?>index.php">
  <img src="<?= BASE_URL ?>megacomic.png" alt="Logo MegaComic"
       style="height: 60px; width: auto; margin-left: -1rem; margin-right: 1rem; padding: 0; object-fit: contain;">
</a>


  <form class="d-flex ms-auto" action="<?= BASE_URL ?>search.php" method="get">
  <input class="form-control bg-dark text-light border-warning search-input" 
         type="search" 
         aria-label="Buscar" 
         name="q">
         
  <button class="btn btn-warning d-flex align-items-center justify-content-center px-3 search-button" type="submit">
    <span class="icon-search" style="font-size: 1.2rem;"></span>
  </button>
</form>

  <div class="ms-3">
    <?php if (isset($_SESSION['admin_logged_in']) && $_SESSION['admin_logged_in'] === true): ?>
      <div class="dropdown">
        <a class="btn btn-outline-warning dropdown-toggle d-flex align-items-center gap-2" href="#" role="button" id="userDropdown" data-bs-toggle="dropdown" aria-expanded="false" style="white-space: nowrap;">
          <!-- Icono persona -->
          <span class="icon-user" style="font-size: 1.3rem; color: orange;"></span>
          <?= htmlspecialchars($_SESSION['admin_username']) ?>
        </a>

        <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="userDropdown">
          <li><a class="dropdown-item" href="<?= BASE_URL ?>admin/upload_manga.php"><span class="icon-books" style="font-size: 0.85rem;"></span> Tus mangas</a></li>
          <li><hr class="dropdown-divider"></li>
          <li><a class="dropdown-item" href="<?= BASE_URL ?>logout.php"><span class="icon-exit" style="font-size: 0.9rem;"></span> Cerrar sesión</a></li>
        </ul>
      </div>
    <?php else: ?>
      <a href="<?= BASE_URL ?>admin/login.php" class="btn btn-outline-light">Acceder admin</a>
    <?php endif; ?>
  </div>
</nav>
